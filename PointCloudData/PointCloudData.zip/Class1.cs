﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.Geometry;
using System.IO;
using System.Reflection;

[assembly: ExtensionApplication(null)]
[assembly: CommandClass(typeof(PointCloudData.Class1))]

namespace PointCloudData
{
public class Class1
{
    //Get RCP file from Solution Directory
    private static string getPCFile()
    {
        /*
        SolutionFolder
        │   
        ├───bin
        └───Debug
        │
        assembly.dll

        */
        var assemblyLoc =
                Assembly.GetExecutingAssembly().Location;
        var debugFolder = 
                Path.GetDirectoryName(assemblyLoc);
        var binFolder = 
                Path.GetDirectoryName(debugFolder);
        var solutionFolder = 
                Path.GetDirectoryName(binFolder);
        var FilePath = 
                solutionFolder +
                       "\\MyOfficeRoom.rcs";
        return FilePath;
    }
    //Write to Editor
    private static void Report(string v)
    {
        Editor ed = Application.DocumentManager.MdiActiveDocument.Editor;
        ed.WriteMessage("\n" + v);
    }

    public static ObjectId AttachPointCloudEx(string filename,
                                              double scale, 
                                              double rotation)
    {
        Point3d location = new Point3d(0, 0, 0);
        Database db = HostApplicationServices.WorkingDatabase;
        ObjectId objid = PointCloudEx.AttachPointCloud(filename,
                                                        location,
                                                        scale,
                                                        rotation,
                                                        db);
        if (objid.IsNull)
            Report("\nFail to get object id of attach point cloud"+
                "by PointCloudEx.AttacPointCloud API");

        return objid;

    }
    
    //Cropping Logic
    //
    public static ErrorStatus addcropping(PointCloudEx pointcloud,
                                          PointCloudCropType type, 
                                          Point3d pt1, Point3d pt2,
                                          bool bInside, bool bInverted)
    {

        PointCloudCrop crop = PointCloudCrop.Create(IntPtr.Zero);
        if (crop == null)
            Report("\nFail to create crop by pointcloudcrop.Create method");
        Point3dCollection points = new Point3dCollection();
        points.Add(pt1);
        points.Add(pt2);
        crop.Vertices = points;
        //In SW Isometric View or OrthoGraphic View
        Vector3d norm = new Vector3d(0, 1, 0);           
        Plane cropPlane = new Plane(pt1, norm);
        crop.CropPlane = cropPlane;
        crop.CropType = type;
        crop.Inside = bInside;
        crop.Inverted = bInverted;
        pointcloud.addCroppingBoundary(crop);
        return ErrorStatus.OK;
    }

       
    [CommandMethod("CropPC")]
    public static void CropPC()
    {
        //attach point cloud into the drawing
        Database db = 
            HostApplicationServices.WorkingDatabase;
        ObjectId objid = 
            AttachPointCloudEx(getPCFile(), 1.0, 0.0);
        Editor ed = 
            Application.DocumentManager.MdiActiveDocument.Editor;
        //get the point cloud object
        using (Transaction t = db.TransactionManager.StartTransaction())
        {
            ViewTableRecord activeVTR = ed.GetCurrentView() as ViewTableRecord;
            //Set VS Preset to Realistic, in Wireframe PC Attach is not supported.
            DBDictionary dict = t.GetObject(db.VisualStyleDictionaryId,
                                OpenMode.ForRead) as DBDictionary;
            activeVTR.VisualStyleId = dict.GetAt("Realistic");
            ed.SetCurrentView(activeVTR);
            ed.UpdateTiledViewportsFromDatabase();
                

            PointCloudEx pcloudex = 
                t.GetObject(objid, OpenMode.ForWrite) as PointCloudEx;

                             
            //Add two cropping to the point cloud
            Point3d crop1_pt1 = new Point3d(-7.0, 12.0, 0);
            Point3d crop1_pt2 = new Point3d(-4.0, 9.0, 0);
            Point3d crop2_pt1 = new Point3d(3.5, 15.0, 0);
            Point3d crop2_pt2 = new Point3d(6.0, 13.0, 0);
            /*Cropping PC in not supported in PerspectiveView*/
            if (activeVTR.PerspectiveEnabled)
            {
                activeVTR.PerspectiveEnabled = false;
            }
            //Rectangle - first corner point, 2nd, 3rd, 4th and first corner point again. 
            addcropping(pcloudex, 
                        PointCloudCropType.Rectangular, 
                        crop1_pt1, crop1_pt2,
                        false, false);
            //Circular - there are 2 points, center point and any point which is on the circle's circumference. 
            addcropping(pcloudex, 
                        PointCloudCropType.Circular, 
                        crop2_pt1, crop2_pt2,
                        false, true);

            //show Cropping
            pcloudex.ShowCropped = true;
            //Now lets us traversing list of croppings
            for (int Index = 0; Index < pcloudex.getCroppingCount(); Index++)
            {

                //Retrieving Croptype
                PointCloudCrop tmpcrop = pcloudex.getPointCloudCropping(Index);
                Report(tmpcrop.CropType.ToString());
            }

            //Zoom the View to PC Extents
            using (ViewTableRecord vtr = new ViewTableRecord())
            {
                vtr.CenterPoint = 
                    new Point2d(pcloudex.Location.X, pcloudex.Location.Z);
                Extents3d extents = 
                    pcloudex.GeomExtents;
                Point2d min2d = 
                    new Point2d(extents.MinPoint.X, extents.MinPoint.Y);
                Point2d max2d =
                    new Point2d(extents.MaxPoint.X, extents.MaxPoint.Y);
                vtr.Height = 
                    max2d.Y - min2d.Y;
                vtr.Width =
                    max2d.X - min2d.X;
                vtr.Target = 
                    activeVTR.Target;
                                       
                ed.SetCurrentView(vtr);
            }
                
            t.Commit();

        }
           
    }

        

    }
}

