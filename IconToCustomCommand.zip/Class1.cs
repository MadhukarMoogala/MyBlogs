﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*AutoCAD*/
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Windows;
using Autodesk.AutoCAD.BoundaryRepresentation;
using Autodesk.AutoCAD.PlottingServices;
using Autodesk.AutoCAD.Internal.DatabaseServices;
using Autodesk.AutoCAD.Customization;
using System.IO;
using System.Reflection;

[assembly: ExtensionApplication(null)]
[assembly: CommandClass(typeof(IconToCustomCommand.CreateTestCuix))]


namespace IconToCustomCommand
    {
    /*Helper Methods*/
    public static class CustomizationExtensions
        {
        public static RibbonTabSource AddNewTab(
        this CustomizationSection instance,
        string name,
        string text = null)
            {
            if (text == null)
                text = name;

            var ribbonRoot = instance.MenuGroup.RibbonRoot;
            var id = "tab" + name;
            var ribbonTabSource = new RibbonTabSource(ribbonRoot);

            ribbonTabSource.Name = name;
            ribbonTabSource.Text = text;
            ribbonTabSource.Id = id;
            ribbonTabSource.ElementID = id;

            ribbonRoot.RibbonTabSources.Add(ribbonTabSource);

            return ribbonTabSource;
            }

        public static RibbonPanelSource AddNewPanel(
        this RibbonTabSource instance,
        string name,
        string text = null)
            {
            if (text == null)
                text = name;

            var ribbonRoot = instance.CustomizationSection.MenuGroup.RibbonRoot;
            var panels = ribbonRoot.RibbonPanelSources;
            var id = "pnl" + name;
            var ribbonPanelSource = new RibbonPanelSource(ribbonRoot);

            ribbonPanelSource.Name = name;
            ribbonPanelSource.Text = text;
            ribbonPanelSource.Id = id;
            ribbonPanelSource.ElementID = id;

            panels.Add(ribbonPanelSource);

            var ribbonPanelSourceReference = new RibbonPanelSourceReference(instance);

            ribbonPanelSourceReference.PanelId = ribbonPanelSource.ElementID;

            instance.Items.Add(ribbonPanelSourceReference);

            return ribbonPanelSource;
            }

        public static RibbonRow AddNewRibbonRow(this RibbonPanelSource instance)
            {
            var row = new RibbonRow(instance);

            instance.Items.Add(row);

            return row;
            }

        public static RibbonRow AddNewRibbonRow(this RibbonRowPanel instance)
            {
            var row = new RibbonRow(instance);

            instance.Items.Add(row);

            return row;
            }

        public static RibbonRowPanel AddNewPanel(this RibbonRow instance)
            {
            var row = new RibbonRowPanel(instance);

            instance.Items.Add(row);

            return row;
            }

        public static RibbonCommandButton AddNewButton(
        this RibbonRow instance,
        string text,
        string commandFriendlyName,
        string command,
        string commandDescription,
        string smallImagePath,
        string largeImagePath,
        RibbonButtonStyle style)
            {

            var customizationSection = instance.CustomizationSection;
            var macroGroups = customizationSection.MenuGroup.MacroGroups;

            MacroGroup macroGroup;

            if (macroGroups.Count == 0)
                macroGroup = new MacroGroup("MacroGroup", customizationSection.MenuGroup);
            else
                macroGroup = macroGroups[0];

            var button = new RibbonCommandButton(instance);
            button.Text = text;

            var commandMacro = "^C^C_" + command;
            var commandId = "ID_" + command;
            var buttonId = "btn" + command;
            var labelId = "lbl" + command;

            var menuMacro = macroGroup.CreateMenuMacro(commandFriendlyName,
            commandMacro,
            commandId,
            commandDescription,
            MacroType.Any,
            smallImagePath,
            largeImagePath,
            labelId);
            var macro = menuMacro.macro;
            /*Associate custom command to ribbonbutton macro*/
            macro.CLICommand = command;

            button.MacroID = menuMacro.ElementID;
            button.ButtonStyle = style;
            instance.Items.Add(button);

            return button;
            }




        }
    public class CreateTestCuix
        {
        [CommandMethod("CreateTestCuix1")]
        public static void CreateTestCuix1()
            {
            var editor = Application.DocumentManager.MdiActiveDocument.Editor;

            try
                {
                var debugFolder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                var customizationSection = new CustomizationSection();
                var menuGroup = customizationSection.MenuGroup;
                var tab = customizationSection.AddNewTab("CuiTestTab");
                var panel = tab.AddNewPanel("Panel");
                var row = panel.AddNewRibbonRow();

                menuGroup.Name = "CuiTest1";

                row.AddNewButton(
                "Smile",
                "Smile",
                "KeepSmiling",
                "How to add BMP icon to Custom Command",
                debugFolder + "\\smile_16.bmp",
                debugFolder + "\\smile_32.bmp",
                RibbonButtonStyle.LargeWithText);


                var fileName = Path.Combine(debugFolder, "CuiTest1.cuix");

                File.Delete(fileName);

                customizationSection.SaveAs(fileName);
                }
            catch (System.Exception ex)
                {
                editor.WriteMessage(Environment.NewLine + ex.Message);
                }
            }
        [CommandMethod("KeepSmiling")]
        public void KeepSmiling()
            {
            Application.ShowAlertDialog("KeepSmiling :D");
            }

        }
    }
    
