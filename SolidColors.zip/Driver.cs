﻿using Autodesk.AutoCAD.BoundaryRepresentation;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidColors
{
    public class Driver
    {
        /// <summary>
        /// Set the environment variable for RealDWG
        /// </summary>
        private static void SetRealDwgEnviormentVar()
        {
            // get executing assembly path
            var realDWGBasePath = "C:\\rd2020\\RealDWG 2020";

            // initialize the support and font folder paths
            var realDwgPath = realDWGBasePath + "\\";
            var realDwgFontsPath = realDWGBasePath + "\\Fonts\\";
            var realDwgSupportPath = realDWGBasePath + "\\Support\\";

            // get current path variable
            var sysPathVariable = Environment.GetEnvironmentVariable("Path");

            // create real DWG path to system variable for application scope
            sysPathVariable = string.Concat(sysPathVariable,
                                            ";",
                                            realDwgPath,
                                            ";",
                                            realDwgFontsPath,
                                            ";",
                                            realDwgSupportPath);
            // Add real DWG path to system variable for application scope
            Environment.SetEnvironmentVariable("Path",
                                               sysPathVariable);
        } // SetRealDwgEnviormentVar

        static void ProcessFile(string aFile)
        {
            try
            {
                DwgLoader oLoader = new DwgLoader();
                oLoader.Load(aFile);
            }
            catch (System.Exception ex)
            {
                throw ex;

            }
        }

        static void Main(string[] args)
        {
            Autodesk.AutoCAD.Runtime.RuntimeSystem.Initialize(new DWGHost(), 1033);
            try
            {
                SetRealDwgEnviormentVar();
                ProcessFile(args[0]);
            }
            catch (Autodesk.AutoCAD.Runtime.Exception ex)
            {

                System.Diagnostics.Trace.WriteLine(ex.Message); ;
            }       

           
        }
    }
    class DWGHost : HostApplicationServices
    {
        public override string FindFile(string fileName, Database database, FindFileHint hint)
        {
            return fileName;
        }

        public override void FatalError(string message)
        {
            System.Windows.Forms.MessageBox.Show(message);
        }

    }

    class DwgLoader
    {
        Database mDatabase;

        List<KeyValuePair<Color,SubentityId>> GetColors(Solid3d solid, List<SubentityId> subentIds)
        {
            List<KeyValuePair<Color, SubentityId>> ColorSubEntityPairs = new List<KeyValuePair<Color, SubentityId>>();
            foreach (SubentityId subentId in subentIds)
            {
                try
                {
                    Color col = solid.GetSubentityColor(subentId);
                    ColorSubEntityPairs.Add(new KeyValuePair<Color, SubentityId>(col, subentId));
                }
                catch (Autodesk.AutoCAD.BoundaryRepresentation.Exception ex)
                {
                    if(ex.ErrorStatus == ErrorStatus.NotApplicable)
                    continue;
                }
                

                
            }
            return ColorSubEntityPairs;
        }
        private void DumpBlockTable(BlockTableRecord aBTR)
        {
            using (Transaction oTransaction = mDatabase.TransactionManager.StartTransaction())
            {
                BlockTableRecordEnumerator itr = aBTR.GetEnumerator();

                while (itr.MoveNext())
                {
                    ObjectId id = itr.Current;
                    DumpEntity(oTransaction, id);

                }
            }
        }
        private void DumpBlockTable(Transaction aTransaction, ObjectId aId)
        {
            BlockTableRecord blockTable = aTransaction.GetObject(aId, OpenMode.ForRead) as BlockTableRecord;
            DumpBlockTable(blockTable);
        }
        private void DumpSolid3d(Transaction tr, ObjectId solId)
        {
            using (OpenCloseTransaction oct = new OpenCloseTransaction())
            {
                Solid3d solid = tr.GetObject(solId, OpenMode.ForRead) as Solid3d;

                ObjectId[] ids = new ObjectId[] { solid.ObjectId };

                FullSubentityPath path =
                  new FullSubentityPath(
                    ids,
                    new SubentityId(SubentityType.Null, IntPtr.Zero)
                  );

                // For storing SubentityIds of cylindrical faces

                List<SubentityId> subentIds = new List<SubentityId>();

                using (Brep brep = new Brep(path))
                {
                    foreach (Autodesk.AutoCAD.BoundaryRepresentation.Face face in brep.Faces)
                    {
                        /*
                        // How to get colors of only cylinderical
                         
                        Autodesk.AutoCAD.Geometry.Surface surf = face.Surface;
                        var ebSurf = surf as Autodesk.AutoCAD.Geometry.ExternalBoundedSurface;
                        if (ebSurf != null && ebSurf.IsCylinder)
                        {
                            subentIds.Add(face.SubentityPath.SubentId);
                        }
                        
                         */
                        subentIds.Add(face.SubentityPath.SubentId);
                    }
                }

                if (subentIds.Count > 0)
                {
                    List<KeyValuePair<Color, SubentityId>> ColorSubEntityPairs = GetColors(solid, subentIds);
                    foreach (var item in ColorSubEntityPairs)
                    {
                        var color = item.Key as Color;
                        SubentityId id = item.Value;
                        Console.WriteLine($"\nColor - {color.ColorNameForDisplay} | SubEntity Index - {id.IndexPtr}");
                    }
                }
               oct.Commit();
            }
        }

        private void DumpEntity(Transaction aTransaction, ObjectId aEntityId)
        {
            Entity ent = aTransaction.GetObject(aEntityId, OpenMode.ForRead) as Entity;
            System.Diagnostics.Debug.Assert(ent != null);
            var rcClass = ent.GetRXClass();

            string name = rcClass.Name;

            switch (name)
            {
                case "AcDbRegion":
                case "AcDbZombieEntity":
                case "AcDbXline":
                case "AcDbViewport":
                case "AcDbAttributeDefinition":
                    // Ignore/Skip
                    break;
                case "AcDbMText":
                    break;
                case "AcDb2dPolyline":
                    break;
                case "AcDb3dPolyline":
                    break;
                case "AcDbSpline":
                    break;
                case "AcDb3dSolid":
                    Solid3d sol = (Solid3d)ent;
                    DumpSolid3d(aTransaction, sol.ObjectId);
                    break;
                case "AcDbEllipse":
                    break;
                case "AcDbText":
                    break;
                case "AcDbCircle":
                    break;
                case "AcDbHatch":
                    break;
                case "AcDbBlockReference":
                    BlockReference blockRef = (BlockReference)ent;
                    DumpBlockTable(aTransaction, blockRef.BlockTableRecord);
                    break;
                case "AcDbPoint":
                    break;
                case "AcDbArc":
                    break;
                case "AcDbLine":
                    break;
                case "AcDbPolyline":
                    break;

                default:
                    System.Console.WriteLine("Type {0}", name);
                    break;
            }
        }
        internal void Load(string v)
        {
            mDatabase = new Database(false, false);
            mDatabase.ReadDwgFile(v, FileOpenMode.OpenForReadAndAllShare, true, "");

            using (Transaction oTransaction = mDatabase.TransactionManager.StartTransaction())
            {
                BlockTable modelSpace = oTransaction.GetObject(mDatabase.BlockTableId, OpenMode.ForRead) as BlockTable;

                foreach (ObjectId id in modelSpace)
                {
                    BlockTableRecord btr = oTransaction.GetObject(id, OpenMode.ForRead) as BlockTableRecord;
                    System.Diagnostics.Debug.Assert(btr != null);
                    System.Diagnostics.Trace.WriteLine(btr.Name);
                    Console.WriteLine($"\nBlockTable -{btr.Name}");
                    DumpBlockTable(btr);
                }
            }
        }
    }
}
